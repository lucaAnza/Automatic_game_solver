__all__ = ['analyseBot', 'screenBot',
           'solverBot', 'decoratori', 'print_coloured']
