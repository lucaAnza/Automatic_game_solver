import pyautogui
import time

while True:
    time.sleep(4)
    pyautogui.press('a')


